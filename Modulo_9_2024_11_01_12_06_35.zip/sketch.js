let palavra; // criando a variável

function setup() {
  createCanvas (400, 400); // criando cenário 
  
  palavra = palavraAleatoria(); // função "palavra"
  
} 
  
  function palavraAleatoria() {
  let palavras = [ "Caminhante","Caminho", "Caminha"];// criando as palavras 
  return random(palavra)// criando a variável palavra}
  
  }
  
  
function inicializaCores () {
  background(220); // cor do fundo
  fill ("black") // cor da letra
  textSize (64); // tamanho das letras 
  textAlign(CENTER, CENTER) // função para alinhar o texto no centro
  } // criando a função "inicialiaCores"

function palavraParcial (minimo, maximo) { 
 let quantidade = map(mouseX, minimo, maximo, 1, palavra.length);// quantidade de letras que serão utilizadas, sempre vai iniciar com o "A"
  let parcial = palavra.substring(0, quantidade); // separando as letras
  return parcial;
}

function draw () { 
inicializaCores();
  
  let texto = palavraParcial(0,width);
  text(texto, 200, 200); //posição do texto
  
}

 function lugaresBacanasParaPassear(diaDaSemana, bairro) {
   
 } // mostrando que podemos modificar nosso projeto de acordo com nossas preferências

